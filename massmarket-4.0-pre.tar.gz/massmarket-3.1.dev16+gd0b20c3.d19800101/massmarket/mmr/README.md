<!--
SPDX-FileCopyrightText: 2025 IETF / draft-bryce-cose-merkle-mountain-range-proofs-02

SPDX-License-Identifier: BSD-2-Clause
-->

# Merkle Mountain Range for Immediately Verifiable and Efficiently Replicable Commitments

Forked the code from https://github.com/robinbryce/draft-bryce-cose-merkle-mountain-range-proofs

Mostly for convenience since in it's upstream form the python code wasn't immediately usable.

## Primary changes

* fixed imports
